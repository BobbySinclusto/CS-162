#ifndef COLORS_H
#define COLORS_H

#define RESET "\u001b[0m"
#define RED "\u001b[31m"
#define GREEN "\u001b[32m"
#define YELLOW "\u001b[33m"
#define BLUE "\u001b[34m"
#define BOLD "\u001b[1m"
#define CLEAR "\u001b[2J"

#endif

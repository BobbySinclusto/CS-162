/***************************************************************************
** File: Event.cpp
** Author: Allen Benjamin
** Date: 02/29/2020
** Description: Represents a Event
**************************************************************************/

#include "Event.h"

Event::Event(int r, int c) {
	row = r;
	col = c;
}
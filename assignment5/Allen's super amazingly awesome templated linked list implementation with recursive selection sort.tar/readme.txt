Name: Allen Benjamin

Program Description: This program shows off the functionality of my linked list implementation.
    First, the user is asked whether they want to create a list of signed or unsigned integers.
    The user is then prompted for numbers to add to the list until they choose not to add another
    number. Then the user is asked if they want to sort the list in ascending or descending
    order, then the list is sorted and displayed. The number of prime numbers in the list is
    also displayed. Finally, the user is asked whether or not they want to repeat the process.

Extra Credit:
    The Linked_List and Node classes are template classes, and the user can choose to have a list
    of signed or unsigned numbers when they run the program. Note: the is_prime function is slow
    when checking large prime numbers and can take up to about 15 seconds per element.

    The sort_descending() function is implemented using a recursive selection sort algorithm in the
    function selection_sort(). (See Linked_List.hpp, line 344)

Compile:
    make

Run:
    ./awesome_program